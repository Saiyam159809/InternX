# Integrating with the existing landing page

The uploaded landing page already has a Company/Recruiter entry point.

Change only the company audience card from:

`onclick="openAuthModal('register', 'company')"`

to:

`onclick="window.location.href='pages/recruiter/auth.html?mode=register'"`

If your landing page is served from a different directory, adjust the relative path accordingly.

This is the only landing-page change required for the recruiter flow. The existing student UI remains untouched.

The existing Supabase authentication code can continue to serve the old student flow until the student backend is migrated. The recruiter flow in this feature deliberately uses Django Authentication because that is the architecture specified in the supplied InternX documents.
