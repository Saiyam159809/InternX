from django.urls import path
from .views import StudentNotificationListView, StudentNotificationReadView
urlpatterns=[
 path("",StudentNotificationListView.as_view()),
 path("<uuid:pk>/read/",StudentNotificationReadView.as_view()),
]
