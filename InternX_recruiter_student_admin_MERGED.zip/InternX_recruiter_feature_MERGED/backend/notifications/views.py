from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import generics
from rest_framework.response import Response
from accounts.permissions import IsStudent, IsAdmin
from interviews.models import Notification
from .serializers import NotificationSerializer

class StudentNotificationListView(generics.ListAPIView):
    serializer_class=NotificationSerializer
    permission_classes=[IsStudent]
    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user).order_by("-created_at")

class StudentNotificationReadView(generics.GenericAPIView):
    permission_classes=[IsStudent]
    def post(self,request,pk):
        n=get_object_or_404(Notification,pk=pk,user=request.user)
        if not n.is_read:
            n.is_read=True; n.read_at=timezone.now(); n.save(update_fields=["is_read","read_at"])
        return Response({"is_read":True})
