from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/auth/", include("accounts.urls")),
    path("api/recruiters/", include("accounts.recruiter_urls")),
    path("api/students/", include("students.urls")),
    path("api/notifications/", include("notifications.urls")),
    path("api/admin/", include("admin_api.urls")),
    path("api/companies/", include("companies.urls")),
    path("api/opportunities/", include("opportunities.urls")),
    path("api/applications/", include("applications.urls")),
    path("api/interviews/", include("interviews.urls")),
]
