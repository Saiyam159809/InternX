import uuid
from django.db import models
from accounts.models import StudentProfile, Resume, User
from opportunities.models import Opportunity


class Application(models.Model):
    class ApplicationMode(models.TextChoices):
        INTERNAL = "internal", "Internal"
        EXTERNAL = "external", "External"

    class Status(models.TextChoices):
        APPLIED = "applied", "Applied"
        UNDER_REVIEW = "under_review", "Under review"
        SHORTLISTED = "shortlisted", "Shortlisted"
        INTERVIEW = "interview", "Interview"
        SELECTED = "selected", "Selected"
        REJECTED = "rejected", "Rejected"
        WITHDRAWN = "withdrawn", "Withdrawn"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name="applications")
    opportunity = models.ForeignKey(Opportunity, on_delete=models.CASCADE, related_name="applications")
    resume = models.ForeignKey(Resume, null=True, blank=True, on_delete=models.SET_NULL, related_name="applications")
    application_mode = models.CharField(max_length=20, choices=ApplicationMode.choices)
    status = models.CharField(max_length=30, choices=Status.choices, default=Status.APPLIED)
    cover_letter = models.TextField(blank=True)
    external_application_url = models.URLField(max_length=1000, blank=True)
    applied_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["student", "opportunity"], name="unique_student_opportunity")
        ]
        indexes = [
            models.Index(fields=["student"]),
            models.Index(fields=["opportunity"]),
            models.Index(fields=["status"]),
            models.Index(fields=["applied_at"]),
        ]


class ApplicationStatusHistory(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    application = models.ForeignKey(Application, on_delete=models.CASCADE, related_name="status_history")
    old_status = models.CharField(max_length=30, choices=Application.Status.choices, null=True, blank=True)
    new_status = models.CharField(max_length=30, choices=Application.Status.choices)
    changed_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    note = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=["application", "created_at"])]
