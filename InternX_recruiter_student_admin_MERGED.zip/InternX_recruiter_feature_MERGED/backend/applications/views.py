from django.db import transaction
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.pagination import PageNumberPagination
from accounts.permissions import IsRecruiter, IsStudent, IsAdmin
from opportunities.models import Opportunity
from .models import Application, ApplicationStatusHistory
from .serializers import ApplicationStatusSerializer, CandidateApplicationSerializer, StudentApplicationSerializer


class RecruiterApplicationListView(APIView):
    permission_classes = [IsRecruiter]

    def get(self, request):
        qs = (
            Application.objects
            .filter(opportunity__created_by=request.user)
            .select_related(
                "student__user",
                "resume",
                "opportunity__company",
            )
            .order_by("-applied_at")
        )

        opportunity_id = request.query_params.get("opportunity")
        status_filter = request.query_params.get("status")
        if opportunity_id:
            qs = qs.filter(opportunity_id=opportunity_id)
        if status_filter:
            qs = qs.filter(status=status_filter)

        paginator = PageNumberPagination()
        page = paginator.paginate_queryset(qs, request, view=self)
        serializer = CandidateApplicationSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)


class RecruiterApplicationDetailView(APIView):
    permission_classes = [IsRecruiter]

    def get(self, request, pk):
        application = (
            Application.objects
            .filter(id=pk, opportunity__created_by=request.user)
            .select_related("student__user", "resume", "opportunity__company")
            .prefetch_related("status_history")
            .first()
        )
        if not application:
            return Response({"detail": "Application not found."}, status=404)

        data = CandidateApplicationSerializer(application).data
        data["status_history"] = [
            {
                "old_status": item.old_status,
                "new_status": item.new_status,
                "note": item.note,
                "created_at": item.created_at,
            }
            for item in application.status_history.all()
        ]
        return Response(data)


class RecruiterApplicationStatusView(APIView):
    permission_classes = [IsRecruiter]

    @transaction.atomic
    def post(self, request, pk):
        application = Application.objects.filter(
            id=pk,
            opportunity__created_by=request.user,
        ).select_related("student__user", "opportunity").first()

        if not application:
            return Response({"detail": "Application not found."}, status=404)

        serializer = ApplicationStatusSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        new_status = serializer.validated_data["status"]
        note = serializer.validated_data.get("note", "")

        if application.status == Application.Status.WITHDRAWN:
            return Response({"detail": "Withdrawn applications cannot be changed by a recruiter."}, status=409)

        if new_status == application.status:
            return Response({"detail": "Application is already in this status."}, status=409)

        allowed_transitions = {
            Application.Status.APPLIED: {Application.Status.UNDER_REVIEW, Application.Status.SHORTLISTED, Application.Status.INTERVIEW, Application.Status.REJECTED},
            Application.Status.UNDER_REVIEW: {Application.Status.SHORTLISTED, Application.Status.INTERVIEW, Application.Status.REJECTED},
            Application.Status.SHORTLISTED: {Application.Status.INTERVIEW, Application.Status.SELECTED, Application.Status.REJECTED},
            Application.Status.INTERVIEW: {Application.Status.SELECTED, Application.Status.REJECTED},
            Application.Status.SELECTED: set(),
            Application.Status.REJECTED: set(),
            Application.Status.WITHDRAWN: set(),
        }
        if new_status not in allowed_transitions[application.status]:
            return Response({"detail": "Invalid application status transition."}, status=409)

        old_status = application.status
        application.status = new_status
        application.save(update_fields=["status", "updated_at"])

        ApplicationStatusHistory.objects.create(
            application=application,
            old_status=old_status,
            new_status=new_status,
            changed_by=request.user,
            note=note,
        )

        # Notify the student after a recruiter changes application status.
        try:
            from interviews.models import Notification
            Notification.objects.create(
                user=application.student.user,
                type="application_status",
                title="Application status updated",
                message=f"Your application for {application.opportunity.title} is now {application.get_status_display()}.",
                related_application=application,
            )
        except Exception:
            # Do not roll back a valid status update if notification persistence fails.
            pass

        return Response(CandidateApplicationSerializer(application).data)


class StudentApplicationListCreateView(APIView):
    permission_classes=[IsStudent]

    def get(self,request):
        qs=Application.objects.filter(student=request.user.student_profile).select_related(
            "opportunity","opportunity__company","resume"
        ).order_by("-applied_at")
        status_filter=request.query_params.get("status")
        if status_filter: qs=qs.filter(status=status_filter)
        paginator=PageNumberPagination(); page=paginator.paginate_queryset(qs,request,view=self)
        return paginator.get_paginated_response(StudentApplicationSerializer(page,many=True).data)

    @transaction.atomic
    def post(self,request):
        opportunity_id=request.data.get("opportunity")
        opportunity=Opportunity.objects.filter(pk=opportunity_id).first()
        if not opportunity:
            return Response({"opportunity":["Opportunity not found."]},status=404)
        student=request.user.student_profile
        if Application.objects.filter(student=student,opportunity=opportunity).exists():
            return Response({"detail":"You have already applied to this opportunity."},status=409)
        serializer=StudentApplicationSerializer(
            data=request.data,
            context={"request":request,"opportunity":opportunity}
        )
        serializer.is_valid(raise_exception=True)
        app=serializer.save(student=student,opportunity=opportunity)
        ApplicationStatusHistory.objects.create(
            application=app,old_status=None,new_status=app.status,changed_by=request.user
        )
        try:
            from interviews.models import Notification
            Notification.objects.create(
                user=request.user,type="application",title="Application submitted",
                message=f"Your application for {opportunity.title} was submitted.",
                related_application=app
            )
        except Exception:
            # Application creation remains successful if notification creation fails.
            pass
        return Response(StudentApplicationSerializer(app).data,status=201)


class StudentApplicationDetailView(APIView):
    permission_classes=[IsStudent]
    def get(self,request,pk):
        app=Application.objects.filter(
            pk=pk,student=request.user.student_profile
        ).select_related("opportunity","opportunity__company","resume").first()
        if not app: return Response({"detail":"Application not found."},status=404)
        data=StudentApplicationSerializer(app).data
        data["status_history"]=[
            {"old_status":x.old_status,"new_status":x.new_status,"note":x.note,"created_at":x.created_at}
            for x in app.status_history.order_by("created_at")
        ]
        return Response(data)


class StudentWithdrawApplicationView(APIView):
    permission_classes=[IsStudent]
    @transaction.atomic
    def post(self,request,pk):
        app=Application.objects.filter(pk=pk,student=request.user.student_profile).first()
        if not app: return Response({"detail":"Application not found."},status=404)
        if app.status in {Application.Status.SELECTED,Application.Status.REJECTED,Application.Status.WITHDRAWN}:
            return Response({"detail":"This application cannot be withdrawn."},status=409)
        old=app.status; app.status=Application.Status.WITHDRAWN; app.save(update_fields=["status","updated_at"])
        ApplicationStatusHistory.objects.create(application=app,old_status=old,new_status=app.status,changed_by=request.user)
        return Response({"status":app.status})


class AdminApplicationListView(APIView):
    permission_classes=[IsAdmin]
    def get(self,request):
        qs=Application.objects.select_related("student__user","opportunity__company").order_by("-applied_at")
        paginator=PageNumberPagination(); page=paginator.paginate_queryset(qs,request,view=self)
        return paginator.get_paginated_response(CandidateApplicationSerializer(page,many=True).data)
