import uuid
from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    initial = True
    dependencies = [("accounts", "0001_initial"), ("opportunities", "0001_initial")]
    operations = [
        migrations.CreateModel(
            name="Application",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("application_mode", models.CharField(choices=[("internal", "Internal"), ("external", "External")], max_length=20)),
                ("status", models.CharField(choices=[("applied", "Applied"), ("under_review", "Under review"), ("shortlisted", "Shortlisted"), ("interview", "Interview"), ("selected", "Selected"), ("rejected", "Rejected"), ("withdrawn", "Withdrawn")], default="applied", max_length=30)),
                ("cover_letter", models.TextField(blank=True)),
                ("external_application_url", models.URLField(blank=True, max_length=1000)),
                ("applied_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("opportunity", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="applications", to="opportunities.opportunity")),
                ("resume", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="applications", to="accounts.resume")),
                ("student", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="applications", to="accounts.studentprofile")),
            ],
            options={"constraints": [models.UniqueConstraint(fields=("student", "opportunity"), name="unique_student_opportunity")], "indexes": [
                models.Index(fields=["student"], name="applications_ap_student_3f9c7a_idx"),
                models.Index(fields=["opportunity"], name="applications_ap_opportu_7d2e4b_idx"),
                models.Index(fields=["status"], name="applications_ap_status_4b6f8e_idx"),
                models.Index(fields=["applied_at"], name="applications_ap_applied_8c1d2e_idx"),
            ]},
        ),
        migrations.CreateModel(
            name="ApplicationStatusHistory",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("old_status", models.CharField(blank=True, choices=[("applied", "Applied"), ("under_review", "Under review"), ("shortlisted", "Shortlisted"), ("interview", "Interview"), ("selected", "Selected"), ("rejected", "Rejected"), ("withdrawn", "Withdrawn")], max_length=30, null=True)),
                ("new_status", models.CharField(choices=[("applied", "Applied"), ("under_review", "Under review"), ("shortlisted", "Shortlisted"), ("interview", "Interview"), ("selected", "Selected"), ("rejected", "Rejected"), ("withdrawn", "Withdrawn")], max_length=30)),
                ("note", models.TextField(blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("application", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="status_history", to="applications.application")),
                ("changed_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to="accounts.user")),
            ],
            options={"indexes": [models.Index(fields=["application", "created_at"], name="applications_ap_applicat_4d6f2e_idx")]},
        ),
    ]
