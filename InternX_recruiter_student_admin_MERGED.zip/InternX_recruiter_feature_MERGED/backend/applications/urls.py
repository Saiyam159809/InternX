from django.urls import path
from .views import (
 RecruiterApplicationDetailView, RecruiterApplicationListView, RecruiterApplicationStatusView,
 StudentApplicationListCreateView, StudentApplicationDetailView, StudentWithdrawApplicationView,
 AdminApplicationListView,
)
urlpatterns=[
 path("mine/",RecruiterApplicationListView.as_view()),
 path("student/",StudentApplicationListCreateView.as_view()),
 path("student/<uuid:pk>/",StudentApplicationDetailView.as_view()),
 path("student/<uuid:pk>/withdraw/",StudentWithdrawApplicationView.as_view()),
 path("admin/",AdminApplicationListView.as_view()),
 path("<uuid:pk>/",RecruiterApplicationDetailView.as_view()),
 path("<uuid:pk>/status/",RecruiterApplicationStatusView.as_view()),
]
