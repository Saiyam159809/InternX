from rest_framework import serializers
from .models import Application


class CandidateApplicationSerializer(serializers.ModelSerializer):
    candidate_name = serializers.SerializerMethodField()
    candidate_email = serializers.EmailField(source="student.user.email", read_only=True)
    opportunity_title = serializers.CharField(source="opportunity.title", read_only=True)
    company_name = serializers.CharField(source="opportunity.company.name", read_only=True)
    resume_name = serializers.CharField(source="resume.file_name", read_only=True, allow_null=True)

    class Meta:
        model = Application
        fields = [
            "id", "candidate_name", "candidate_email", "opportunity_title",
            "company_name", "resume_name", "application_mode", "status",
            "cover_letter", "external_application_url", "applied_at", "updated_at",
        ]
        read_only_fields = fields

    def get_candidate_name(self, obj):
        profile = obj.student
        return f"{profile.first_name} {profile.last_name}".strip()


class ApplicationStatusSerializer(serializers.Serializer):
    status = serializers.ChoiceField(choices=Application.Status.choices)
    note = serializers.CharField(required=False, allow_blank=True, max_length=2000)


class StudentApplicationSerializer(serializers.ModelSerializer):
    opportunity_title = serializers.CharField(source="opportunity.title", read_only=True)
    company_name = serializers.CharField(source="opportunity.company.name", read_only=True)

    class Meta:
        model = Application
        fields = [
            "id","student","opportunity","opportunity_title","company_name","resume",
            "application_mode","status","cover_letter","external_application_url",
            "applied_at","updated_at"
        ]
        read_only_fields = ["id","student","status","applied_at","updated_at","opportunity_title","company_name"]

    def validate(self, attrs):
        from django.utils import timezone
        opportunity=self.context["opportunity"]
        if opportunity.status != opportunity.Status.PUBLISHED:
            raise serializers.ValidationError({"opportunity":"This opportunity is not accepting applications."})
        if opportunity.deadline and opportunity.deadline < timezone.now():
            raise serializers.ValidationError({"opportunity":"The application deadline has passed."})

        resume=attrs.get("resume")
        if resume and resume.student_id != self.context["request"].user.student_profile.user_id:
            raise serializers.ValidationError({"resume":"You can only use your own resume."})

        mode=attrs.get("application_mode")
        if mode != opportunity.application_mode:
            raise serializers.ValidationError({"application_mode":"Application mode must match the opportunity."})
        if mode == Application.ApplicationMode.EXTERNAL:
            url=attrs.get("external_application_url")
            if not url:
                raise serializers.ValidationError({"external_application_url":"Required for external applications."})
            if url != opportunity.external_url:
                raise serializers.ValidationError({"external_application_url":"The application URL must match the opportunity's external URL."})
        return attrs
