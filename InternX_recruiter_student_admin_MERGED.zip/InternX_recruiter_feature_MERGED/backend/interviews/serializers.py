from django.utils import timezone
from rest_framework import serializers
from .models import Interview


class InterviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Interview
        fields = [
            "id", "application", "scheduled_at", "mode",
            "location_or_link", "instructions", "status",
            "created_at", "updated_at"
        ]
        read_only_fields = ["id", "application", "created_at", "updated_at"]

    def validate(self, attrs):
        scheduled_at = attrs.get("scheduled_at", getattr(self.instance, "scheduled_at", None))
        status_value = attrs.get("status", getattr(self.instance, "status", Interview.Status.SCHEDULED))
        if scheduled_at and scheduled_at <= timezone.now() and status_value in {
            Interview.Status.SCHEDULED,
            Interview.Status.RESCHEDULED,
        }:
            raise serializers.ValidationError({"scheduled_at": "Interview time must be in the future."})

        if self.instance:
            current = self.instance.status
            allowed = {
                Interview.Status.SCHEDULED: {
                    Interview.Status.SCHEDULED,
                    Interview.Status.COMPLETED,
                    Interview.Status.CANCELLED,
                    Interview.Status.RESCHEDULED,
                },
                Interview.Status.RESCHEDULED: {
                    Interview.Status.RESCHEDULED,
                    Interview.Status.COMPLETED,
                    Interview.Status.CANCELLED,
                },
                Interview.Status.COMPLETED: {Interview.Status.COMPLETED},
                Interview.Status.CANCELLED: {Interview.Status.CANCELLED},
            }
            if status_value not in allowed[current]:
                raise serializers.ValidationError({"status": "Invalid interview status transition."})
        return attrs
