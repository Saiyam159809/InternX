import uuid
from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    initial = True
    dependencies = [("accounts", "0001_initial"), ("applications", "0001_initial")]
    operations = [
        migrations.CreateModel(
            name="Interview",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("scheduled_at", models.DateTimeField()),
                ("mode", models.CharField(blank=True, max_length=50)),
                ("location_or_link", models.URLField(blank=True, max_length=1000)),
                ("instructions", models.TextField(blank=True)),
                ("status", models.CharField(choices=[("scheduled", "Scheduled"), ("completed", "Completed"), ("cancelled", "Cancelled"), ("rescheduled", "Rescheduled")], default="scheduled", max_length=20)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("application", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="interviews", to="applications.application")),
            ],
            options={"indexes": [
                models.Index(fields=["application"], name="interviews_i_applicat_3f9c7a_idx"),
                models.Index(fields=["scheduled_at"], name="interviews_i_schedul_7d2e4b_idx"),
                models.Index(fields=["status"], name="interviews_i_status_4b6f8e_idx"),
            ]},
        ),
        migrations.CreateModel(
            name="Notification",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("type", models.CharField(max_length=50)),
                ("title", models.CharField(max_length=250)),
                ("message", models.TextField()),
                ("is_read", models.BooleanField(default=False)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("read_at", models.DateTimeField(blank=True, null=True)),
                ("related_application", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="notifications", to="applications.application")),
                ("related_interview", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="notifications", to="interviews.interview")),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="notifications", to="accounts.user")),
            ],
            options={"indexes": [
                models.Index(fields=["user", "is_read"], name="interviews_n_user_id_1a2b3c_idx"),
                models.Index(fields=["user", "created_at"], name="interviews_n_user_id_4d5e6f_idx"),
            ]},
        ),
    ]
