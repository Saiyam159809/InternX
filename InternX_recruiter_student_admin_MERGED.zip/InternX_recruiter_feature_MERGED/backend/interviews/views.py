from django.db import transaction
from django.utils import timezone
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.pagination import PageNumberPagination
from accounts.permissions import IsRecruiter, IsStudent
from applications.models import Application, ApplicationStatusHistory
from .models import Interview, Notification
from .serializers import InterviewSerializer


class RecruiterInterviewListCreateView(APIView):
    permission_classes = [IsRecruiter]

    def get(self, request):
        qs = (
            Interview.objects
            .filter(application__opportunity__created_by=request.user)
            .select_related("application__student__user", "application__opportunity")
            .order_by("scheduled_at")
        )
        paginator = PageNumberPagination()
        page = paginator.paginate_queryset(qs, request, view=self)
        serializer = InterviewSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)

    @transaction.atomic
    def post(self, request):
        serializer = InterviewSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        application_id = request.data.get("application")
        application = (
            Application.objects
            .filter(id=application_id, opportunity__created_by=request.user)
            .select_related("student__user", "opportunity")
            .first()
        )
        if not application:
            return Response({"application": ["Application not found or not owned by recruiter."]}, status=404)

        if application.status in [Application.Status.REJECTED, Application.Status.WITHDRAWN]:
            return Response({"detail": "An interview cannot be created for a rejected or withdrawn application."}, status=409)

        interview = serializer.save(application=application)

        if application.status != Application.Status.INTERVIEW:
            old_status = application.status
            application.status = Application.Status.INTERVIEW
            application.save(update_fields=["status", "updated_at"])
            ApplicationStatusHistory.objects.create(
                application=application,
                old_status=old_status,
                new_status=Application.Status.INTERVIEW,
                changed_by=request.user,
                note="Application moved to interview when interview was scheduled.",
            )

        Notification.objects.create(
            user=application.student.user,
            type="interview",
            title="Interview scheduled",
            message=f"An interview has been scheduled for {application.opportunity.title}.",
            related_application=application,
            related_interview=interview,
        )

        return Response(InterviewSerializer(interview).data, status=status.HTTP_201_CREATED)


class RecruiterInterviewDetailView(APIView):
    permission_classes = [IsRecruiter]

    def _get(self, request, pk):
        return Interview.objects.filter(
            id=pk,
            application__opportunity__created_by=request.user,
        ).select_related("application").first()

    @transaction.atomic
    def put(self, request, pk):
        interview = self._get(request, pk)
        if not interview:
            return Response({"detail": "Interview not found."}, status=404)

        serializer = InterviewSerializer(interview, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    @transaction.atomic
    def patch(self, request, pk):
        return self.put(request, pk)


class StudentInterviewListView(APIView):
    permission_classes = [IsStudent]

    def get(self, request):
        qs = Interview.objects.filter(
            application__student=request.user.student_profile
        ).select_related("application", "application__opportunity").order_by("scheduled_at")
        paginator = PageNumberPagination()
        page = paginator.paginate_queryset(qs, request, view=self)
        return paginator.get_paginated_response(InterviewSerializer(page, many=True).data)
