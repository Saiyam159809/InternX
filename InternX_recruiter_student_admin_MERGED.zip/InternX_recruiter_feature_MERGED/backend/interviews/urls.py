from django.urls import path
from .views import RecruiterInterviewDetailView, RecruiterInterviewListCreateView, StudentInterviewListView
urlpatterns=[
 path("",RecruiterInterviewListCreateView.as_view()),
 path("student/",StudentInterviewListView.as_view()),
 path("<uuid:pk>/",RecruiterInterviewDetailView.as_view()),
]
