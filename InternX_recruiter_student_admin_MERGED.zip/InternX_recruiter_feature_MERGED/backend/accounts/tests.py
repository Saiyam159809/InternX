from django.test import TestCase
from rest_framework.test import APIClient
from .models import User


class RecruiterAuthTests(TestCase):
    def test_recruiter_can_register_and_login(self):
        client = APIClient()
        response = client.post("/api/auth/recruiter/register/", {
            "email": "recruiter@example.com",
            "password": "StrongPass123!",
            "first_name": "Test",
            "last_name": "Recruiter",
        }, format="json")
        self.assertEqual(response.status_code, 201)
        self.assertTrue(User.objects.filter(email="recruiter@example.com", role="recruiter").exists())

        client.post("/api/auth/logout/", format="json")
        response = client.post("/api/auth/recruiter/login/", {
            "email": "recruiter@example.com",
            "password": "StrongPass123!",
        }, format="json")
        self.assertEqual(response.status_code, 200)

from django.utils import timezone
from datetime import timedelta
from companies.models import Company, RecruiterCompany
from opportunities.models import Opportunity
from applications.models import Application
from interviews.models import Interview


class RecruiterSecurityTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.password = "StrongPass123!"
        self.recruiter = User.objects.create_user(
            email="recruiter@example.com",
            password=self.password,
            role=User.Role.RECRUITER,
        )
        from .models import RecruiterProfile, StudentProfile
        self.profile = RecruiterProfile.objects.create(user=self.recruiter, first_name="Recruiter")
        self.other_recruiter = User.objects.create_user(
            email="other@example.com", password=self.password, role=User.Role.RECRUITER
        )
        self.other_profile = RecruiterProfile.objects.create(user=self.other_recruiter, first_name="Other")
        self.company = Company.objects.create(name="Owned Co")
        self.other_company = Company.objects.create(name="Other Co")
        RecruiterCompany.objects.create(recruiter=self.profile, company=self.company, is_primary=True)
        RecruiterCompany.objects.create(recruiter=self.other_profile, company=self.other_company, is_primary=True)
        self.client.force_authenticate(self.recruiter)

    def test_opportunity_cannot_be_reassigned_to_unowned_company(self):
        opportunity = Opportunity.objects.create(
            company=self.company,
            created_by=self.recruiter,
            title="Intern",
            description="Description",
            opportunity_type="internship",
        )
        response = self.client.patch(
            f"/api/opportunities/{opportunity.id}/",
            {"company": str(self.other_company.id)},
            format="json",
        )
        self.assertEqual(response.status_code, 400)
        opportunity.refresh_from_db()
        self.assertEqual(opportunity.company_id, self.company.id)

    def test_interview_cannot_be_reassigned_to_unowned_application(self):
        from .models import StudentProfile
        student_user = User.objects.create_user(email="student@example.com", password="Student123!", role=User.Role.STUDENT)
        student = StudentProfile.objects.create(user=student_user, first_name="Student")
        opportunity = Opportunity.objects.create(
            company=self.company, created_by=self.recruiter, title="Intern", description="Description", opportunity_type="internship"
        )
        other_opportunity = Opportunity.objects.create(
            company=self.other_company, created_by=self.other_recruiter, title="Other", description="Description", opportunity_type="internship"
        )
        application = Application.objects.create(student=student, opportunity=opportunity, application_mode="internal")
        other_application = Application.objects.create(student=student, opportunity=other_opportunity, application_mode="internal")
        interview = Interview.objects.create(application=application, scheduled_at=timezone.now() + timedelta(days=1))
        response = self.client.patch(
            f"/api/interviews/{interview.id}/",
            {"application": str(other_application.id)},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        interview.refresh_from_db()
        self.assertEqual(interview.application_id, application.id)

    def test_weak_password_is_rejected(self):
        response = self.client.post("/api/auth/recruiter/register/", {
            "email": "weak@example.com",
            "password": "password",
            "first_name": "Weak",
        }, format="json")
        self.assertEqual(response.status_code, 400)
