from django.urls import path
from .views import CurrentUserView, LogoutView, RecruiterLoginView, RecruiterRegisterView, csrf_cookie_view

urlpatterns = [
    path("csrf/", csrf_cookie_view),
    path("recruiter/register/", RecruiterRegisterView.as_view()),
    path("recruiter/login/", RecruiterLoginView.as_view()),
    path("student/register/", StudentRegisterView.as_view()),
    path("student/login/", StudentLoginView.as_view()),
    path("admin/login/", AdminLoginView.as_view()),
    path("logout/", LogoutView.as_view()),
    path("me/", CurrentUserView.as_view()),
]
