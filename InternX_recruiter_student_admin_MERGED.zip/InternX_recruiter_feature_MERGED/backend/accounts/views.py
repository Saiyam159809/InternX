from django.contrib.auth import login, logout
from django.http import JsonResponse
from django.views.decorators.csrf import ensure_csrf_cookie
from django.utils.decorators import method_decorator
from django.db import transaction
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.throttling import AnonRateThrottle
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import RecruiterProfile, User
from .permissions import IsRecruiter
from .serializers import (
    RecruiterLoginSerializer,
    RecruiterProfileSerializer,
    RecruiterRegisterSerializer,
    StudentRegisterSerializer, StudentLoginSerializer, AdminLoginSerializer,
)


@ensure_csrf_cookie
def csrf_cookie_view(request):
    return JsonResponse({"csrfToken": request.META.get("CSRF_COOKIE", "")})


class RecruiterRegisterThrottle(AnonRateThrottle):
    scope = "register"


class RecruiterLoginThrottle(AnonRateThrottle):
    scope = "login"


class RecruiterRegisterView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [RecruiterRegisterThrottle]

    def post(self, request):
        serializer = RecruiterRegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        login(request, user)
        return Response(
            {
                "message": "Recruiter account created successfully.",
                "user": {"id": str(user.id), "email": user.email, "role": user.role},
            },
            status=status.HTTP_201_CREATED,
        )


class RecruiterLoginView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [RecruiterLoginThrottle]

    def post(self, request):
        serializer = RecruiterLoginSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data["user"]
        login(request, user)
        return Response({
            "message": "Signed in successfully.",
            "user": {"id": str(user.id), "email": user.email, "role": user.role},
        })


class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        logout(request)
        return Response({"message": "Signed out successfully."})


@method_decorator(ensure_csrf_cookie, name='dispatch')
class CurrentUserView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        data = {
            "id": str(user.id),
            "email": user.email,
            "role": user.role,
        }
        if user.role == User.Role.RECRUITER:
            profile = getattr(user, "recruiter_profile", None)
            if profile is not None:
                data["profile"] = RecruiterProfileSerializer(profile).data
        elif user.role == User.Role.STUDENT:
            profile = getattr(user, "student_profile", None)
            if profile is not None:
                data["profile"] = {
                    "first_name": profile.first_name,
                    "last_name": profile.last_name,
                    "phone": profile.phone,
                    "location": profile.location,
                    "graduation_year": profile.graduation_year,
                }
        return Response(data)


class RecruiterProfileView(APIView):
    permission_classes = [IsRecruiter]

    def get(self, request):
        return Response(RecruiterProfileSerializer(request.user.recruiter_profile).data)

    @transaction.atomic
    def put(self, request):
        profile = request.user.recruiter_profile
        serializer = RecruiterProfileSerializer(profile, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class StudentRegisterThrottle(AnonRateThrottle):
    scope = "register"


class StudentLoginThrottle(AnonRateThrottle):
    scope = "login"


class StudentRegisterView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [StudentRegisterThrottle]

    @transaction.atomic
    def post(self, request):
        serializer = StudentRegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        login(request, user)
        return Response({
            "message": "Student account created successfully.",
            "user": {"id": str(user.id), "email": user.email, "role": user.role},
        }, status=status.HTTP_201_CREATED)


class StudentLoginView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [StudentLoginThrottle]

    def post(self, request):
        serializer = StudentLoginSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data["user"]
        login(request, user)
        return Response({
            "message": "Signed in successfully.",
            "user": {"id": str(user.id), "email": user.email, "role": user.role},
        })


class AdminLoginView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [AnonRateThrottle]

    def post(self, request):
        serializer = AdminLoginSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data["user"]
        login(request, user)
        return Response({
            "message": "Admin signed in successfully.",
            "user": {"id": str(user.id), "email": user.email, "role": user.role},
        })
