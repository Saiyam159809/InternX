import uuid
from django.db import migrations, models
import django.db.models.deletion
from django.db.models import Q

class Migration(migrations.Migration):
    dependencies = [("accounts", "0001_initial")]
    operations = [
        migrations.AddField(model_name="studentprofile", name="phone", field=models.CharField(blank=True,max_length=20)),
        migrations.AddField(model_name="studentprofile", name="date_of_birth", field=models.DateField(blank=True,null=True)),
        migrations.AddField(model_name="studentprofile", name="bio", field=models.TextField(blank=True)),
        migrations.AddField(model_name="studentprofile", name="location", field=models.CharField(blank=True,max_length=150)),
        migrations.AddField(model_name="studentprofile", name="graduation_year", field=models.PositiveSmallIntegerField(blank=True,null=True)),
        migrations.AddIndex(model_name="studentprofile", index=models.Index(fields=["location"], name="accounts_st_location_idx")),
        migrations.AddConstraint(
            model_name="studentprofile",
            constraint=models.CheckConstraint(
                condition=Q(graduation_year__isnull=True) | Q(graduation_year__gte=2000, graduation_year__lte=2100),
                name="student_graduation_year_range",
            ),
        ),
        migrations.CreateModel(
            name="Education",
            fields=[
                ("id",models.UUIDField(default=uuid.uuid4,editable=False,primary_key=True,serialize=False)),
                ("institution",models.CharField(max_length=200)),
                ("degree",models.CharField(blank=True,max_length=150)),
                ("field_of_study",models.CharField(blank=True,max_length=150)),
                ("start_year",models.PositiveSmallIntegerField(blank=True,null=True)),
                ("end_year",models.PositiveSmallIntegerField(blank=True,null=True)),
                ("grade",models.CharField(blank=True,max_length=50)),
                ("created_at",models.DateTimeField(auto_now_add=True)),
                ("student",models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name="education",to="accounts.studentprofile")),
            ],
            options={"indexes":[models.Index(fields=["student"],name="accounts_ed_student_idx")]},
        ),
        migrations.AddConstraint(
            model_name="education",
            constraint=models.CheckConstraint(
                condition=Q(end_year__isnull=True) | Q(start_year__isnull=True) | Q(end_year__gte=models.F("start_year")),
                name="education_year_range",
            ),
        ),
        migrations.CreateModel(
            name="Skill",
            fields=[
                ("id",models.UUIDField(default=uuid.uuid4,editable=False,primary_key=True,serialize=False)),
                ("name",models.CharField(max_length=100,unique=True)),
                ("created_at",models.DateTimeField(auto_now_add=True)),
            ],
            options={"ordering":["name"]},
        ),
        migrations.CreateModel(
            name="StudentSkill",
            fields=[
                ("id",models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name="ID")),
                ("proficiency",models.CharField(blank=True,max_length=50)),
                ("created_at",models.DateTimeField(auto_now_add=True)),
                ("skill",models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name="student_skills",to="accounts.skill")),
                ("student",models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name="student_skills",to="accounts.studentprofile")),
            ],
            options={"indexes":[models.Index(fields=["skill"],name="accounts_st_skill_idx")]},
        ),
        migrations.AddConstraint(
            model_name="studentskill",
            constraint=models.UniqueConstraint(fields=("student","skill"),name="unique_student_skill"),
        ),
        migrations.CreateModel(
            name="Project",
            fields=[
                ("id",models.UUIDField(default=uuid.uuid4,editable=False,primary_key=True,serialize=False)),
                ("title",models.CharField(max_length=200)),
                ("description",models.TextField(blank=True)),
                ("project_url",models.URLField(blank=True,max_length=500)),
                ("technologies",models.TextField(blank=True)),
                ("start_date",models.DateField(blank=True,null=True)),
                ("end_date",models.DateField(blank=True,null=True)),
                ("created_at",models.DateTimeField(auto_now_add=True)),
                ("updated_at",models.DateTimeField(auto_now=True)),
                ("student",models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name="projects",to="accounts.studentprofile")),
            ],
            options={"indexes":[models.Index(fields=["student"],name="accounts_pr_student_idx")]},
        ),
        migrations.AddConstraint(
            model_name="project",
            constraint=models.CheckConstraint(
                condition=Q(end_date__isnull=True) | Q(start_date__isnull=True) | Q(end_date__gte=models.F("start_date")),
                name="project_date_range",
            ),
        ),
    ]
