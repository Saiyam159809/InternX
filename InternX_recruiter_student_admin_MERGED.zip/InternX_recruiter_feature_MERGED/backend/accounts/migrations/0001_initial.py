# Generated manually for the recruiter feature.
import uuid
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(
            name="User",
            fields=[
                ("password", models.CharField(max_length=128, verbose_name="password")),
                ("last_login", models.DateTimeField(blank=True, null=True, verbose_name="last login")),
                ("is_superuser", models.BooleanField(default=False, help_text="Designates that this user has all permissions without explicitly assigning them.", verbose_name="superuser status")),
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("email", models.EmailField(max_length=255, unique=True)),
                ("role", models.CharField(choices=[("student", "Student"), ("recruiter", "Recruiter"), ("admin", "Admin")], max_length=20)),
                ("is_active", models.BooleanField(default=True)),
                ("is_staff", models.BooleanField(default=False)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("groups", models.ManyToManyField(blank=True, help_text="The groups this user belongs to. A user will get all permissions granted to each of their groups.", related_name="user_set", related_query_name="user", to="auth.group", verbose_name="groups")),
                ("user_permissions", models.ManyToManyField(blank=True, help_text="Specific permissions for this user.", related_name="user_set", related_query_name="user", to="auth.permission", verbose_name="user permissions")),
            ],
            options={"abstract": False},
        ),
        migrations.CreateModel(
            name="RecruiterProfile",
            fields=[
                ("user", models.OneToOneField(on_delete=models.deletion.CASCADE, primary_key=True, related_name="recruiter_profile", serialize=False, to="accounts.user")),
                ("first_name", models.CharField(max_length=100)),
                ("last_name", models.CharField(blank=True, max_length=100)),
                ("job_title", models.CharField(blank=True, max_length=150)),
                ("phone", models.CharField(blank=True, max_length=20)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name="StudentProfile",
            fields=[
                ("user", models.OneToOneField(on_delete=models.deletion.CASCADE, primary_key=True, related_name="student_profile", serialize=False, to="accounts.user")),
                ("first_name", models.CharField(max_length=100)),
                ("last_name", models.CharField(blank=True, max_length=100)),
            ],
        ),
        migrations.CreateModel(
            name="Resume",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("file_name", models.CharField(max_length=255)),
                ("storage_path", models.CharField(max_length=500, unique=True)),
                ("file_type", models.CharField(max_length=100)),
                ("file_size", models.BigIntegerField()),
                ("is_default", models.BooleanField(default=False)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("student", models.ForeignKey(on_delete=models.deletion.CASCADE, related_name="resumes", to="accounts.studentprofile")),
            ],
            options={"indexes": [models.Index(fields=["student"], name="accounts_re_student_9f0c7f_idx")]},
        ),
    ]
