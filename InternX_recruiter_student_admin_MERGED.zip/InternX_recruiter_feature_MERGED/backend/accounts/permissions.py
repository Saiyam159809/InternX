from rest_framework.permissions import BasePermission
from .models import User


class IsRecruiter(BasePermission):
    message = "Recruiter access is required."

    def has_permission(self, request, view):
        return bool(
            request.user
            and request.user.is_authenticated
            and request.user.role == User.Role.RECRUITER
            and request.user.is_active
        )


class IsStudent(BasePermission):
    message = "Student access is required."

    def has_permission(self, request, view):
        return bool(
            request.user and request.user.is_authenticated
            and request.user.role == User.Role.STUDENT
            and request.user.is_active
        )


class IsAdmin(BasePermission):
    message = "Administrator access is required."

    def has_permission(self, request, view):
        return bool(
            request.user and request.user.is_authenticated
            and request.user.role == User.Role.ADMIN
            and request.user.is_active
        )
