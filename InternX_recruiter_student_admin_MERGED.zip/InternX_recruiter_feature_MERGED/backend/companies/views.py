from django.db import transaction
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from accounts.permissions import IsRecruiter
from .models import Company, RecruiterCompany
from .serializers import CompanySerializer, RecruiterCompanySerializer


class CompanyListCreateView(APIView):
    permission_classes = [IsRecruiter]

    def get(self, request):
        links = RecruiterCompany.objects.filter(recruiter=request.user.recruiter_profile).select_related("company")
        return Response(RecruiterCompanySerializer(links, many=True).data)

    @transaction.atomic
    def post(self, request):
        serializer = CompanySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        company = serializer.save()
        RecruiterCompany.objects.filter(
            recruiter=request.user.recruiter_profile,
            is_primary=True,
        ).update(is_primary=False)
        RecruiterCompany.objects.create(
            recruiter=request.user.recruiter_profile,
            company=company,
            is_primary=True,
        )
        return Response(CompanySerializer(company).data, status=status.HTTP_201_CREATED)


class CompanyDetailView(APIView):
    permission_classes = [IsRecruiter]

    def _get_owned_company(self, request, pk):
        return Company.objects.filter(
            id=pk,
            recruiters=request.user.recruiter_profile,
        ).first()

    def get(self, request, pk):
        company = self._get_owned_company(request, pk)
        if not company:
            return Response({"detail": "Company not found."}, status=404)
        return Response(CompanySerializer(company).data)

    @transaction.atomic
    def put(self, request, pk):
        company = self._get_owned_company(request, pk)
        if not company:
            return Response({"detail": "Company not found."}, status=404)
        serializer = CompanySerializer(company, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)
