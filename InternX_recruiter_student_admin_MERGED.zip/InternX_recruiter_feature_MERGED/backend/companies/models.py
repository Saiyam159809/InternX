import uuid
from django.db import models
from django.db.models import Q
from accounts.models import RecruiterProfile


class Company(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    website = models.URLField(max_length=500, blank=True)
    industry = models.CharField(max_length=150, blank=True)
    location = models.CharField(max_length=150, blank=True)
    logo_path = models.CharField(max_length=500, blank=True)
    recruiters = models.ManyToManyField(
        RecruiterProfile,
        through="RecruiterCompany",
        related_name="companies",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=["name"]),
            models.Index(fields=["industry"]),
        ]

    def __str__(self):
        return self.name


class RecruiterCompany(models.Model):
    recruiter = models.ForeignKey(RecruiterProfile, on_delete=models.CASCADE)
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    is_primary = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["recruiter", "company"], name="unique_recruiter_company"),
            models.UniqueConstraint(
                fields=["recruiter"],
                condition=Q(is_primary=True),
                name="unique_primary_company_per_recruiter",
            ),
        ]
        indexes = [models.Index(fields=["company"])]

    def __str__(self):
        return f"{self.recruiter} - {self.company}"
