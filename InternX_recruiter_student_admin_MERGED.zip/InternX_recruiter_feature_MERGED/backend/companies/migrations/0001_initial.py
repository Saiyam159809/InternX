import uuid
from django.db import migrations, models
import django.db.models.deletion
from django.db.models import Q

class Migration(migrations.Migration):
    initial = True
    dependencies = [("accounts", "0001_initial")]
    operations = [
        migrations.CreateModel(
            name="Company",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("name", models.CharField(max_length=200)),
                ("description", models.TextField(blank=True)),
                ("website", models.URLField(blank=True, max_length=500)),
                ("industry", models.CharField(blank=True, max_length=150)),
                ("location", models.CharField(blank=True, max_length=150)),
                ("logo_path", models.CharField(blank=True, max_length=500)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"indexes": [models.Index(fields=["name"], name="companies_co_name_9f1c4b_idx"), models.Index(fields=["industry"], name="companies_co_indust_9f2c3b_idx")]},
        ),
        migrations.CreateModel(
            name="RecruiterCompany",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("is_primary", models.BooleanField(default=False)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("company", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to="companies.company")),
                ("recruiter", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to="accounts.recruiterprofile")),
            ],
            options={"constraints": [models.UniqueConstraint(fields=("recruiter", "company"), name="unique_recruiter_company"), models.UniqueConstraint(condition=Q(("is_primary", True)), fields=("recruiter",), name="unique_primary_company_per_recruiter")], "indexes": [models.Index(fields=["company"], name="companies_re_company__6a2d4d_idx")]},
        ),
        migrations.AddField(
            model_name="company", name="recruiters",
            field=models.ManyToManyField(related_name="companies", through="companies.RecruiterCompany", to="accounts.recruiterprofile"),
        ),
    ]
