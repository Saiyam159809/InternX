from rest_framework import serializers
from .models import Company, RecruiterCompany


class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = [
            "id", "name", "description", "website", "industry", "location",
            "logo_path", "created_at", "updated_at"
        ]
        read_only_fields = ["id", "created_at", "updated_at"]

    def validate_name(self, value):
        if not value.strip():
            raise serializers.ValidationError("Company name cannot be empty.")
        return value.strip()

    def validate_website(self, value):
        return value.strip()


class RecruiterCompanySerializer(serializers.ModelSerializer):
    company = CompanySerializer(read_only=True)

    class Meta:
        model = RecruiterCompany
        fields = ["company", "is_primary", "created_at"]
        read_only_fields = ["created_at"]
