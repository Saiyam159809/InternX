from django.urls import path
from .views import *
urlpatterns=[
 path("profile/",ProfileView.as_view()),
 path("education/",EducationListCreateView.as_view()),
 path("education/<uuid:pk>/",EducationDetailView.as_view()),
 path("skills/",SkillListView.as_view()),
 path("skills/me/",MySkillListCreateView.as_view()),
 path("skills/me/<uuid:skill_id>/",MySkillDeleteView.as_view()),
 path("projects/",ProjectListCreateView.as_view()),
 path("projects/<uuid:pk>/",ProjectDetailView.as_view()),
 path("resumes/",ResumeListCreateView.as_view()),
 path("resumes/<uuid:pk>/",ResumeDetailView.as_view()),
 path("resumes/<uuid:pk>/default/",ResumeDefaultView.as_view()),
]
