from pathlib import Path
from uuid import uuid4
from django.shortcuts import get_object_or_404
from django.core.exceptions import ValidationError
from rest_framework import generics, status
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from accounts.models import StudentProfile, Education, Skill, StudentSkill, Project, Resume
from accounts.permissions import IsStudent
from .serializers import StudentProfileSerializer, EducationSerializer, SkillSerializer, StudentSkillSerializer, ProjectSerializer, ResumeSerializer
from .storage import upload, remove

MAX_RESUME_SIZE=5*1024*1024
ALLOWED_EXT={".pdf",".doc",".docx"}
ALLOWED_TYPES={"application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document"}

class ProfileView(generics.RetrieveUpdateAPIView):
    serializer_class=StudentProfileSerializer
    permission_classes=[IsStudent]
    def get_object(self): return get_object_or_404(StudentProfile,user=self.request.user)

class EducationListCreateView(generics.ListCreateAPIView):
    serializer_class=EducationSerializer
    permission_classes=[IsStudent]
    def get_queryset(self): return Education.objects.filter(student=self.request.user.student_profile).order_by("-created_at")
    def perform_create(self,serializer): serializer.save(student=self.request.user.student_profile)

class EducationDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class=EducationSerializer
    permission_classes=[IsStudent]
    def get_queryset(self): return Education.objects.filter(student=self.request.user.student_profile)

class SkillListView(generics.ListAPIView):
    serializer_class=SkillSerializer
    permission_classes=[IsStudent]
    queryset=Skill.objects.all()

class MySkillListCreateView(generics.ListCreateAPIView):
    serializer_class=StudentSkillSerializer
    permission_classes=[IsStudent]
    def get_queryset(self): return StudentSkill.objects.filter(student=self.request.user.student_profile).select_related("skill")
    def perform_create(self,serializer):
        student=self.request.user.student_profile
        skill_id=serializer.validated_data["skill_id"]
        if StudentSkill.objects.filter(student=student,skill_id=skill_id).exists():
            from rest_framework.exceptions import ValidationError as DRFValidationError
            raise DRFValidationError({"skill_id":"This skill is already added."})
        serializer.save(student=student,skill_id=skill_id)

class MySkillDeleteView(generics.DestroyAPIView):
    permission_classes=[IsStudent]
    def get_object(self): return get_object_or_404(StudentSkill,student=self.request.user.student_profile,skill_id=self.kwargs["skill_id"])

class ProjectListCreateView(generics.ListCreateAPIView):
    serializer_class=ProjectSerializer
    permission_classes=[IsStudent]
    def get_queryset(self): return Project.objects.filter(student=self.request.user.student_profile).order_by("-updated_at")
    def perform_create(self,serializer): serializer.save(student=self.request.user.student_profile)

class ProjectDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class=ProjectSerializer
    permission_classes=[IsStudent]
    def get_queryset(self): return Project.objects.filter(student=self.request.user.student_profile)

class ResumeListCreateView(generics.ListCreateAPIView):
    serializer_class=ResumeSerializer
    permission_classes=[IsStudent]
    parser_classes=[MultiPartParser,FormParser]
    def get_queryset(self): return Resume.objects.filter(student=self.request.user.student_profile).order_by("-created_at")
    def create(self,request,*args,**kwargs):
        f=request.FILES.get("file")
        if not f: return Response({"file":["Resume file is required."]},status=400)
        ext=Path(f.name).suffix.lower()
        if ext not in ALLOWED_EXT: return Response({"file":["Only PDF, DOC and DOCX files are allowed."]},status=400)
        if f.size<=0 or f.size>MAX_RESUME_SIZE: return Response({"file":["Resume must be between 1 byte and 5 MB."]},status=400)
        ctype=getattr(f,"content_type","")
        if ctype and ctype not in ALLOWED_TYPES: return Response({"file":["Unsupported resume content type."]},status=400)
        path=f"resumes/{uuid4()}-{Path(f.name).name}"
        try:
            upload(path,f.read(),ctype or "application/octet-stream")
        except Exception:
            return Response({"detail":"Resume upload failed. Please try again."},status=502)
        student=request.user.student_profile
        resume=Resume.objects.create(student=student,file_name=f.name,storage_path=path,file_type=ctype or "application/octet-stream",file_size=f.size,is_default=not Resume.objects.filter(student=student).exists())
        return Response(ResumeSerializer(resume).data,status=201)

class ResumeDetailView(generics.RetrieveDestroyAPIView):
    serializer_class=ResumeSerializer
    permission_classes=[IsStudent]
    def get_queryset(self): return Resume.objects.filter(student=self.request.user.student_profile)
    def perform_destroy(self,instance):
        try: remove(instance.storage_path)
        except Exception:
            from rest_framework.exceptions import APIException
            raise APIException("Resume deletion failed. Please try again.")
        instance.delete()

class ResumeDefaultView(generics.GenericAPIView):
    permission_classes=[IsStudent]
    def post(self,request,pk):
        resume=get_object_or_404(Resume,pk=pk,student=request.user.student_profile)
        Resume.objects.filter(student=resume.student).update(is_default=False)
        resume.is_default=True; resume.save(update_fields=["is_default"])
        return Response(ResumeSerializer(resume).data)
