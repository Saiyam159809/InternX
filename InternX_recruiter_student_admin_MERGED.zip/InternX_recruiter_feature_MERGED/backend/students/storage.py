import os
from supabase import create_client
BUCKET = os.getenv("SUPABASE_RESUME_BUCKET","resumes")
def client():
    url=os.getenv("SUPABASE_URL")
    key=os.getenv("SUPABASE_SERVICE_ROLE_KEY")
    if not url or not key:
        raise RuntimeError("Supabase storage configuration is missing.")
    return create_client(url,key)
def upload(path, content, content_type):
    client().storage.from_(BUCKET).upload(path, content, {"content-type":content_type,"upsert":False})
def remove(path):
    client().storage.from_(BUCKET).remove([path])
