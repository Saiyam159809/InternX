from rest_framework import serializers
from accounts.models import StudentProfile, Education, Skill, StudentSkill, Project, Resume

class StudentProfileSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(source="user.email", read_only=True)
    class Meta:
        model = StudentProfile
        fields = ["user","email","first_name","last_name","phone","date_of_birth","bio","location","graduation_year"]
        read_only_fields = ["user","email"]
    def validate_graduation_year(self, value):
        if value is not None and not 2000 <= value <= 2100:
            raise serializers.ValidationError("Graduation year must be between 2000 and 2100.")
        return value

class EducationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Education
        fields = "__all__"
        read_only_fields = ["id","student","created_at"]
    def validate(self, attrs):
        if attrs.get("start_year") and attrs.get("end_year") and attrs["end_year"] < attrs["start_year"]:
            raise serializers.ValidationError({"end_year":"End year cannot be before start year."})
        return attrs

class SkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = Skill
        fields = ["id","name","created_at"]
        read_only_fields = fields

class StudentSkillSerializer(serializers.ModelSerializer):
    skill = SkillSerializer(read_only=True)
    skill_id = serializers.UUIDField(write_only=True)
    class Meta:
        model = StudentSkill
        fields = ["skill","skill_id","proficiency","created_at"]
        read_only_fields = ["created_at"]
    def validate_skill_id(self, value):
        if not Skill.objects.filter(id=value).exists():
            raise serializers.ValidationError("Skill does not exist.")
        return value

class ProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = "__all__"
        read_only_fields = ["id","student","created_at","updated_at"]
    def validate(self, attrs):
        if attrs.get("start_date") and attrs.get("end_date") and attrs["end_date"] < attrs["start_date"]:
            raise serializers.ValidationError({"end_date":"End date cannot be before start date."})
        return attrs

class ResumeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Resume
        fields = ["id","file_name","storage_path","file_type","file_size","is_default","created_at"]
        read_only_fields = fields
