from django.urls import path
from .views import (
    OpportunityStatusView, RecruiterOpportunityDetailView, RecruiterOpportunityListCreateView,
    StudentOpportunityListView, StudentOpportunityDetailView,
    AdminOpportunityListView, AdminOpportunityDetailView,
)
urlpatterns=[
 path("mine/",RecruiterOpportunityListCreateView.as_view()),
 path("student/",StudentOpportunityListView.as_view()),
 path("student/<uuid:pk>/",StudentOpportunityDetailView.as_view()),
 path("admin/",AdminOpportunityListView.as_view()),
 path("admin/<uuid:pk>/",AdminOpportunityDetailView.as_view()),
 path("<uuid:pk>/",RecruiterOpportunityDetailView.as_view()),
 path("<uuid:pk>/status/",OpportunityStatusView.as_view()),
]
