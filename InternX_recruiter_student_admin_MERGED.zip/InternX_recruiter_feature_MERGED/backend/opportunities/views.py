from django.db import transaction
from django.utils import timezone
from django.db.models import Q
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.pagination import PageNumberPagination
from accounts.permissions import IsRecruiter, IsStudent, IsAdmin
from companies.models import Company
from .models import Opportunity
from .serializers import OpportunitySerializer


class RecruiterOpportunityListCreateView(APIView):
    permission_classes = [IsRecruiter]

    def get(self, request):
        qs = (
            Opportunity.objects
            .filter(created_by=request.user)
            .select_related("company")
            .order_by("-created_at")
        )
        paginator = PageNumberPagination()
        page = paginator.paginate_queryset(qs, request, view=self)
        serializer = OpportunitySerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)

    @transaction.atomic
    def post(self, request):
        company_id = request.data.get("company")
        if not company_id:
            return Response({"company": ["Select a company."]}, status=400)

        company = Company.objects.filter(
            id=company_id,
            recruiters=request.user.recruiter_profile,
        ).first()
        if not company:
            return Response({"company": ["You can only use a company linked to your recruiter account."]}, status=403)

        serializer = OpportunitySerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        opportunity = serializer.save(created_by=request.user, company=company)
        return Response(OpportunitySerializer(opportunity).data, status=status.HTTP_201_CREATED)


class RecruiterOpportunityDetailView(APIView):
    permission_classes = [IsRecruiter]

    def _get(self, request, pk):
        return Opportunity.objects.filter(
            id=pk,
            created_by=request.user,
        ).select_related("company").first()

    def get(self, request, pk):
        opportunity = self._get(request, pk)
        if not opportunity:
            return Response({"detail": "Opportunity not found."}, status=404)
        return Response(OpportunitySerializer(opportunity).data)

    @transaction.atomic
    def put(self, request, pk):
        opportunity = self._get(request, pk)
        if not opportunity:
            return Response({"detail": "Opportunity not found."}, status=404)

        if opportunity.status == Opportunity.Status.CLOSED:
            return Response({"detail": "Closed opportunities cannot be edited."}, status=409)

        serializer = OpportunitySerializer(opportunity, data=request.data, partial=True, context={"request": request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    @transaction.atomic
    def patch(self, request, pk):
        return self.put(request, pk)


class OpportunityStatusView(APIView):
    permission_classes = [IsRecruiter]

    @transaction.atomic
    def post(self, request, pk):
        opportunity = Opportunity.objects.filter(id=pk, created_by=request.user).first()
        if not opportunity:
            return Response({"detail": "Opportunity not found."}, status=404)

        new_status = request.data.get("status")
        allowed = {
            Opportunity.Status.DRAFT,
            Opportunity.Status.PUBLISHED,
            Opportunity.Status.CLOSED,
        }
        if new_status not in allowed:
            return Response({"status": ["Status must be draft, published, or closed."]}, status=400)

        if new_status == Opportunity.Status.PUBLISHED:
            if not opportunity.deadline:
                return Response({"deadline": ["A published opportunity requires a deadline."]}, status=400)
            if opportunity.deadline <= timezone.now():
                return Response({"deadline": ["Deadline must be in the future."]}, status=400)

        if opportunity.status == Opportunity.Status.CLOSED and new_status != Opportunity.Status.CLOSED:
            return Response({"detail": "A closed opportunity cannot be reopened."}, status=409)

        opportunity.status = new_status
        opportunity.save(update_fields=["status", "updated_at"])
        return Response(OpportunitySerializer(opportunity).data)


class StudentOpportunityListView(APIView):
    permission_classes = [IsStudent]

    def get(self, request):
        qs = Opportunity.objects.select_related("company").filter(status=Opportunity.Status.PUBLISHED)
        now = timezone.now()
        qs = qs.filter(Q(deadline__isnull=True) | Q(deadline__gte=now))

        q = request.query_params.get("q", "").strip()
        if q:
            qs = qs.filter(
                Q(title__icontains=q) | Q(description__icontains=q) |
                Q(requirements__icontains=q) | Q(eligibility__icontains=q) |
                Q(company__name__icontains=q)
            )
        for field in ("opportunity_type", "work_mode", "location"):
            value=request.query_params.get(field,"").strip()
            if value:
                qs=qs.filter(**{f"{field}__icontains":value})

        paginator=PageNumberPagination()
        page=paginator.paginate_queryset(qs.order_by("-created_at"),request,view=self)
        return paginator.get_paginated_response(OpportunitySerializer(page,many=True).data)


class StudentOpportunityDetailView(APIView):
    permission_classes=[IsStudent]
    def get(self,request,pk):
        opportunity=Opportunity.objects.select_related("company").filter(
            pk=pk,status=Opportunity.Status.PUBLISHED
        ).filter(Q(deadline__isnull=True)|Q(deadline__gte=timezone.now())).first()
        if not opportunity:
            return Response({"detail":"Opportunity not found or no longer available."},status=404)
        return Response(OpportunitySerializer(opportunity).data)


class AdminOpportunityListView(APIView):
    permission_classes=[IsAdmin]
    def get(self,request):
        qs=Opportunity.objects.select_related("company").all().order_by("-created_at")
        q=request.query_params.get("q","").strip()
        if q: qs=qs.filter(Q(title__icontains=q)|Q(company__name__icontains=q))
        status_filter=request.query_params.get("status","").strip()
        if status_filter: qs=qs.filter(status=status_filter)
        paginator=PageNumberPagination(); page=paginator.paginate_queryset(qs,request,view=self)
        return paginator.get_paginated_response(OpportunitySerializer(page,many=True).data)

    @transaction.atomic
    def post(self,request):
        serializer=OpportunitySerializer(data=request.data,context={"request":request})
        serializer.is_valid(raise_exception=True)
        obj=serializer.save(created_by=request.user)
        return Response(OpportunitySerializer(obj).data,status=201)

class AdminOpportunityDetailView(APIView):
    permission_classes=[IsAdmin]
    def get(self,request,pk):
        obj=Opportunity.objects.select_related("company").filter(pk=pk).first()
        if not obj: return Response({"detail":"Opportunity not found."},status=404)
        return Response(OpportunitySerializer(obj).data)
    @transaction.atomic
    def patch(self,request,pk):
        obj=Opportunity.objects.filter(pk=pk).first()
        if not obj: return Response({"detail":"Opportunity not found."},status=404)
        serializer=OpportunitySerializer(obj,data=request.data,partial=True,context={"request":request})
        serializer.is_valid(raise_exception=True); serializer.save()
        return Response(serializer.data)
    def delete(self,request,pk):
        obj=Opportunity.objects.filter(pk=pk).first()
        if not obj: return Response({"detail":"Opportunity not found."},status=404)
        obj.delete(); return Response(status=204)
