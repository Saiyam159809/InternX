import uuid
from django.db import models
from accounts.models import User
from companies.models import Company


class Opportunity(models.Model):
    class OpportunityType(models.TextChoices):
        INTERNSHIP = "internship", "Internship"
        FULL_TIME = "full_time", "Full time"
        CAMPUS = "campus_placement", "Campus placement"
        OFF_CAMPUS = "off_campus", "Off campus"

    class WorkMode(models.TextChoices):
        ONSITE = "onsite", "Onsite"
        REMOTE = "remote", "Remote"
        HYBRID = "hybrid", "Hybrid"

    class ApplicationMode(models.TextChoices):
        INTERNAL = "internal", "Internal"
        EXTERNAL = "external", "External"

    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        PUBLISHED = "published", "Published"
        CLOSED = "closed", "Closed"
        EXPIRED = "expired", "Expired"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    company = models.ForeignKey(Company, on_delete=models.PROTECT, related_name="opportunities")
    created_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name="created_opportunities")
    title = models.CharField(max_length=250)
    description = models.TextField()
    opportunity_type = models.CharField(max_length=30, choices=OpportunityType.choices)
    work_mode = models.CharField(max_length=20, choices=WorkMode.choices, blank=True)
    location = models.CharField(max_length=150, blank=True)
    salary_min = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    salary_max = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    eligibility = models.TextField(blank=True)
    requirements = models.TextField(blank=True)
    application_mode = models.CharField(max_length=20, choices=ApplicationMode.choices, default=ApplicationMode.INTERNAL)
    external_url = models.URLField(max_length=1000, blank=True)
    deadline = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=["company"]),
            models.Index(fields=["created_by"]),
            models.Index(fields=["opportunity_type"]),
            models.Index(fields=["status"]),
            models.Index(fields=["deadline"]),
            models.Index(fields=["location"]),
            models.Index(fields=["work_mode"]),
            models.Index(fields=["status", "deadline"]),
        ]

    def __str__(self):
        return self.title
