from django.utils import timezone
from rest_framework import serializers
from .models import Opportunity
from companies.models import Company


class OpportunitySerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(source="company.name", read_only=True)

    class Meta:
        model = Opportunity
        fields = [
            "id", "company", "company_name", "created_by", "title", "description",
            "opportunity_type", "work_mode", "location", "salary_min", "salary_max",
            "eligibility", "requirements", "application_mode", "external_url",
            "deadline", "status", "created_at", "updated_at"
        ]
        read_only_fields = ["id", "created_by", "company_name", "created_at", "updated_at"]

    def validate(self, attrs):
        salary_min = attrs.get("salary_min", getattr(self.instance, "salary_min", None))
        salary_max = attrs.get("salary_max", getattr(self.instance, "salary_max", None))
        if salary_min is not None and salary_max is not None and salary_max < salary_min:
            raise serializers.ValidationError({"salary_max": "Salary maximum cannot be less than salary minimum."})

        mode = attrs.get("application_mode", getattr(self.instance, "application_mode", None))
        external_url = attrs.get("external_url", getattr(self.instance, "external_url", ""))
        if mode == Opportunity.ApplicationMode.EXTERNAL and not external_url:
            raise serializers.ValidationError({"external_url": "External application URL is required."})

        deadline = attrs.get("deadline", getattr(self.instance, "deadline", None))
        resulting_status = attrs.get("status", getattr(self.instance, "status", Opportunity.Status.DRAFT))
        if deadline and deadline <= timezone.now() and resulting_status == Opportunity.Status.PUBLISHED:
            raise serializers.ValidationError({"deadline": "A published opportunity must have a future deadline."})

        title = attrs.get("title", getattr(self.instance, "title", ""))
        description = attrs.get("description", getattr(self.instance, "description", ""))
        if not title.strip():
            raise serializers.ValidationError({"title": "Title is required."})
        if not description.strip():
            raise serializers.ValidationError({"description": "Description is required."})

        request = self.context.get("request")
        company = attrs.get("company")
        if request and company is not None and hasattr(request.user, "recruiter_profile"):
            if not Company.objects.filter(
                id=company.id,
                recruiters=request.user.recruiter_profile,
            ).exists():
                raise serializers.ValidationError({
                    "company": "You can only use a company linked to your recruiter account."
                })
        return attrs
