import uuid
from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    initial = True
    dependencies = [("accounts", "0001_initial"), ("companies", "0001_initial")]
    operations = [
        migrations.CreateModel(
            name="Opportunity",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("title", models.CharField(max_length=250)),
                ("description", models.TextField()),
                ("opportunity_type", models.CharField(choices=[("internship", "Internship"), ("full_time", "Full time"), ("campus_placement", "Campus placement"), ("off_campus", "Off campus")], max_length=30)),
                ("work_mode", models.CharField(blank=True, choices=[("onsite", "Onsite"), ("remote", "Remote"), ("hybrid", "Hybrid")], max_length=20)),
                ("location", models.CharField(blank=True, max_length=150)),
                ("salary_min", models.DecimalField(blank=True, decimal_places=2, max_digits=12, null=True)),
                ("salary_max", models.DecimalField(blank=True, decimal_places=2, max_digits=12, null=True)),
                ("eligibility", models.TextField(blank=True)),
                ("requirements", models.TextField(blank=True)),
                ("application_mode", models.CharField(choices=[("internal", "Internal"), ("external", "External")], default="internal", max_length=20)),
                ("external_url", models.URLField(blank=True, max_length=1000)),
                ("deadline", models.DateTimeField(blank=True, null=True)),
                ("status", models.CharField(choices=[("draft", "Draft"), ("published", "Published"), ("closed", "Closed"), ("expired", "Expired")], default="draft", max_length=20)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("company", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="opportunities", to="companies.company")),
                ("created_by", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="created_opportunities", to="accounts.user")),
            ],
            options={"indexes": [
                models.Index(fields=["company"], name="opportunities_op_company_1f8f7c_idx"),
                models.Index(fields=["created_by"], name="opportunities_op_created_7c5b3d_idx"),
                models.Index(fields=["opportunity_type"], name="opportunities_op_type_3b7f6a_idx"),
                models.Index(fields=["status"], name="opportunities_op_status_2d7a8e_idx"),
                models.Index(fields=["deadline"], name="opportunities_op_deadli_5c7a8f_idx"),
                models.Index(fields=["location"], name="opportunities_op_locati_8a1d2c_idx"),
                models.Index(fields=["work_mode"], name="opportunities_op_work_m_4b8f2e_idx"),
                models.Index(fields=["status", "deadline"], name="opportunities_op_status_9e2b4a_idx"),
            ]},
        )
    ]
