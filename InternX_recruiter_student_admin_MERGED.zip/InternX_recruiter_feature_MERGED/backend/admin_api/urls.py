from django.urls import path
from .views import AdminUserListView,AdminUserDetailView,AdminCompanyListCreateView,AdminCompanyDetailView
urlpatterns=[
 path("users/",AdminUserListView.as_view()),
 path("users/<uuid:pk>/",AdminUserDetailView.as_view()),
 path("companies/",AdminCompanyListCreateView.as_view()),
 path("companies/<uuid:pk>/",AdminCompanyDetailView.as_view()),
]
