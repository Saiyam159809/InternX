from rest_framework import serializers
from accounts.models import User
from companies.models import Company

class AdminUserSerializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=["id","email","role","is_active","created_at","updated_at"]
        read_only_fields=["id","email","role","created_at","updated_at"]

class AdminCompanySerializer(serializers.ModelSerializer):
    class Meta:
        model=Company
        fields=["id","name","description","website","industry","location","logo_path","created_at","updated_at"]
        read_only_fields=["id","created_at","updated_at"]
    def validate_name(self,value):
        if not value.strip(): raise serializers.ValidationError("Company name is required.")
        return value.strip()
