from django.contrib.auth import get_user_model
from django.db.models import Q
from django.db.models.deletion import ProtectedError
from rest_framework import generics, status
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.response import Response
from accounts.permissions import IsAdmin
from companies.models import Company
from .serializers import AdminUserSerializer, AdminCompanySerializer

User=get_user_model()

class AdminUserListView(generics.ListAPIView):
    serializer_class=AdminUserSerializer
    permission_classes=[IsAdmin]
    filter_backends=[SearchFilter,OrderingFilter]
    search_fields=["email"]
    ordering_fields=["created_at","email","role","is_active"]
    queryset=User.objects.all().order_by("-created_at")

class AdminUserDetailView(generics.RetrieveUpdateAPIView):
    serializer_class=AdminUserSerializer
    permission_classes=[IsAdmin]
    queryset=User.objects.all()
    http_method_names=["get","patch","head","options"]
    def perform_update(self,serializer):
        if self.get_object().pk==self.request.user.pk and serializer.validated_data.get("is_active") is False:
            from rest_framework.exceptions import ValidationError
            raise ValidationError({"is_active":"You cannot deactivate your own admin account."})
        serializer.save()

class AdminCompanyListCreateView(generics.ListCreateAPIView):
    serializer_class=AdminCompanySerializer
    permission_classes=[IsAdmin]
    filter_backends=[SearchFilter,OrderingFilter]
    search_fields=["name","industry","location"]
    ordering_fields=["name","created_at","industry"]
    queryset=Company.objects.all().order_by("name")

class AdminCompanyDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class=AdminCompanySerializer
    permission_classes=[IsAdmin]
    queryset=Company.objects.all()
    def destroy(self,request,*args,**kwargs):
        try:
            return super().destroy(request,*args,**kwargs)
        except ProtectedError:
            return Response({"detail":"Company cannot be deleted while opportunities reference it."},status=status.HTTP_409_CONFLICT)
