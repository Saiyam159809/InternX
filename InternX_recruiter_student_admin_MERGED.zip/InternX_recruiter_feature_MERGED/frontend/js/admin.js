async function adminLogin(e){
 e.preventDefault();const b=e.target.querySelector("button");b.disabled=true;
 try{await api("/api/auth/admin/login/",{method:"POST",body:JSON.stringify({email:e.target.email.value,password:e.target.password.value})});location.href="/pages/admin/dashboard.html"}
 catch(err){showError("auth-error",err)}finally{b.disabled=false}
}
async function adminUsers(){
 const el=document.getElementById("users");el.innerHTML="<p>Loading...</p>";
 try{const d=await api("/api/admin/users/");el.innerHTML=(d.results||[]).map(u=>`<tr><td>${esc(u.email)}</td><td>${esc(u.role)}</td><td>${u.is_active?"Active":"Inactive"}</td><td><button onclick="toggleUser('${u.id}',${!u.is_active})">Toggle</button></td></tr>`).join("")}
 catch(err){el.innerHTML=`<tr><td colspan="4">${esc(err.message)}</td></tr>`}
}
async function toggleUser(id,active){try{await api(`/api/admin/users/${id}/`,{method:"PATCH",body:JSON.stringify({is_active:active})});await adminUsers()}catch(err){alert(err.message)}}
async function adminCompanies(){
 const el=document.getElementById("companies");el.innerHTML="<p>Loading...</p>";
 try{const d=await api("/api/admin/companies/");el.innerHTML=(d.results||d||[]).map(c=>`<article><strong>${esc(c.name)}</strong><p>${esc(c.industry)} · ${esc(c.location)}</p></article>`).join("")||"<p>No companies.</p>"}
 catch(err){el.innerHTML=`<p>${esc(err.message)}</p>`}
}
async function adminOpportunities(){
 const el=document.getElementById("admin-opportunities");el.innerHTML="<p>Loading...</p>";
 try{const d=await api("/api/opportunities/admin/");el.innerHTML=(d.results||[]).map(o=>`<article><strong>${esc(o.title)}</strong><p>${esc(o.company_name)} · ${esc(o.status)}</p><button onclick="moderateOpportunity('${o.id}','published')">Publish</button> <button onclick="moderateOpportunity('${o.id}','closed')">Close</button></article>`).join("")||"<p>No opportunities.</p>"}
 catch(err){el.innerHTML=`<p>${esc(err.message)}</p>`}
}
async function moderateOpportunity(id,status){try{await api(`/api/opportunities/admin/${id}/`,{method:"PATCH",body:JSON.stringify({status})});await adminOpportunities()}catch(err){alert(err.message)}}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
