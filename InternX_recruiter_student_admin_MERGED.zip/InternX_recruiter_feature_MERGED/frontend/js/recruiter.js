const API_BASE = window.INTERNX_API_BASE || "http://127.0.0.1:8000/api";

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const state = {
  user: null,
  companies: [],
  opportunities: [],
  applications: [],
  interviews: []
};

function showMessage(type, message) {
  const error = $("#page-error");
  const success = $("#page-success");
  error.classList.add("hidden");
  success.classList.add("hidden");
  const target = type === "error" ? error : success;
  target.textContent = message;
  target.classList.remove("hidden");
  window.setTimeout(() => target.classList.add("hidden"), 4500);
}

function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  return parts.length === 2 ? parts.pop().split(";").shift() : null;
}

async function api(path, options = {}) {
  const config = { credentials: "include", ...options };
  config.headers = { ...(options.headers || {}) };

  if (config.body && typeof config.body !== "string") {
    config.headers["Content-Type"] = "application/json";
    config.body = JSON.stringify(config.body);
  }

  const csrf = getCookie("csrftoken");
  if (csrf && !["GET", "HEAD", "OPTIONS"].includes((config.method || "GET").toUpperCase())) {
    config.headers["X-CSRFToken"] = csrf;
  }

  const response = await fetch(`${API_BASE}${path}`, config);
  const text = await response.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { detail: text || "Unexpected server response." }; }

  if (!response.ok) {
    const message = data.detail || Object.values(data).flat().join(" ") || `Request failed (${response.status}).`;
    const error = new Error(message);
    error.status = response.status;
    throw error;
  }
  return data;
}

function formObject(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function toApiDate(localValue) {
  if (!localValue) return null;
  return new Date(localValue).toISOString();
}

function toLocalDateTime(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  const pad = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

async function loadMe() {
  state.user = await api("/auth/me/");
  if (state.user.role !== "recruiter") {
    throw new Error("This page is only available to recruiter accounts.");
  }
  $("#recruiter-email").textContent = state.user.email;
}

async function loadProfile() {
  const data = await api("/recruiters/profile/");
  const form = $("#profile-form");
  form.elements.first_name.value = data.first_name || "";
  form.elements.last_name.value = data.last_name || "";
  form.elements.job_title.value = data.job_title || "";
  form.elements.phone.value = data.phone || "";
  $("#profile-email").value = data.email || "";
}

async function loadCompanies() {
  state.companies = await api("/companies/");
  const form = $("#company-form");
  if (state.companies.length) {
    const company = state.companies.find(x => x.is_primary)?.company || state.companies[0].company;
    form.elements.id.value = company.id;
    form.elements.name.value = company.name || "";
    form.elements.description.value = company.description || "";
    form.elements.website.value = company.website || "";
    form.elements.industry.value = company.industry || "";
    form.elements.location.value = company.location || "";
  } else {
    form.reset();
  }
  populateCompanySelect();
}

function populateCompanySelect() {
  const select = $("#opportunity-company");
  select.innerHTML = state.companies.map(x => `<option value="${x.company.id}">${escapeHtml(x.company.name)}</option>`).join("");
}

async function saveProfile(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = formObject(form);
  await api("/recruiters/profile/", { method: "PUT", body: payload });
  showMessage("success", "Recruiter profile saved.");
}

async function saveCompany(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = formObject(form);
  const id = payload.id;
  delete payload.id;

  if (id) {
    await api(`/companies/${id}/`, { method: "PUT", body: payload });
  } else {
    await api("/companies/", { method: "POST", body: payload });
  }
  await loadCompanies();
  showMessage("success", "Company profile saved.");
}

async function loadOpportunities() {
  $("#opportunities-loading").classList.remove("hidden");
  try {
    const data = await api("/opportunities/mine/");
    state.opportunities = Array.isArray(data) ? data : (data.results || []);
    renderOpportunities();
  } finally {
    $("#opportunities-loading").classList.add("hidden");
  }
}

function renderOpportunities() {
  const list = $("#opportunities-list");
  if (!state.opportunities.length) {
    list.innerHTML = `<div class="item"><p class="muted">No opportunities yet. Create your first one.</p></div>`;
    return;
  }
  list.innerHTML = state.opportunities.map(o => `
    <article class="item">
      <div class="item-head">
        <div>
          <h3 class="item-title">${escapeHtml(o.title)}</h3>
          <p class="muted">${escapeHtml(o.company_name || "")}</p>
        </div>
        <span class="badge">${escapeHtml(o.status)}</span>
      </div>
      <div class="meta">
        <span class="badge">${escapeHtml(o.opportunity_type)}</span>
        <span class="badge">${escapeHtml(o.work_mode || "Work mode not set")}</span>
        <span class="badge">${o.deadline ? `Deadline: ${new Date(o.deadline).toLocaleString()}` : "No deadline"}</span>
      </div>
      <p>${escapeHtml((o.description || "").slice(0, 240))}${o.description?.length > 240 ? "…" : ""}</p>
      <div class="actions">
        <button class="btn btn-ghost" data-edit-opportunity="${o.id}">Edit</button>
        ${o.status !== "published" && o.status !== "closed" ? `<button class="btn btn-primary" data-opportunity-status="${o.id}" data-status="published">Publish</button>` : ""}
        ${o.status === "published" ? `<button class="btn btn-ghost" data-opportunity-status="${o.id}" data-status="closed">Close</button>` : ""}
      </div>
    </article>
  `).join("");
}

function openOpportunityModal(opportunity = null) {
  const modal = $("#opportunity-modal");
  const form = $("#opportunity-form");
  form.reset();
  form.elements.id.value = opportunity?.id || "";
  if (opportunity) {
    $("#opportunity-modal-title").textContent = "Edit opportunity";
    form.elements.company.value = opportunity.company;
    form.elements.title.value = opportunity.title;
    form.elements.description.value = opportunity.description;
    form.elements.opportunity_type.value = opportunity.opportunity_type;
    form.elements.work_mode.value = opportunity.work_mode || "";
    form.elements.location.value = opportunity.location || "";
    form.elements.salary_min.value = opportunity.salary_min ?? "";
    form.elements.salary_max.value = opportunity.salary_max ?? "";
    form.elements.eligibility.value = opportunity.eligibility || "";
    form.elements.requirements.value = opportunity.requirements || "";
    form.elements.application_mode.value = opportunity.application_mode;
    form.elements.external_url.value = opportunity.external_url || "";
    form.elements.deadline.value = toLocalDateTime(opportunity.deadline);
    form.elements.status.value = opportunity.status === "published" ? "published" : "draft";
  } else {
    $("#opportunity-modal-title").textContent = "Create opportunity";
    form.elements.status.value = "draft";
    if (state.companies[0]) form.elements.company.value = state.companies[0].company.id;
  }
  toggleExternalUrl();
  modal.classList.remove("hidden");
}

function closeModals() {
  $$(".modal").forEach(m => m.classList.add("hidden"));
}

function toggleExternalUrl() {
  $("#external-url-wrap").classList.toggle("hidden", $("#application-mode").value !== "external");
}

async function saveOpportunity(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = formObject(form);
  const id = payload.id;
  delete payload.id;
  payload.salary_min = payload.salary_min === "" ? null : payload.salary_min;
  payload.salary_max = payload.salary_max === "" ? null : payload.salary_max;
  payload.deadline = toApiDate(payload.deadline);
  if (payload.application_mode === "internal") payload.external_url = "";

  if (id) {
    await api(`/opportunities/${id}/`, { method: "PUT", body: payload });
  } else {
    await api("/opportunities/mine/", { method: "POST", body: payload });
  }
  closeModals();
  await loadOpportunities();
  showMessage("success", id ? "Opportunity updated." : "Opportunity created.");
}

async function updateOpportunityStatus(id, status) {
  await api(`/opportunities/${id}/status/`, { method: "POST", body: { status } });
  await loadOpportunities();
  showMessage("success", `Opportunity ${status}.`);
}

async function loadApplications() {
  $("#applications-loading").classList.remove("hidden");
  try {
    const statusFilter = $("#application-status-filter").value;
    const query = statusFilter ? `?status=${encodeURIComponent(statusFilter)}` : "";
    const data = await api(`/applications/mine/${query}`);
    state.applications = Array.isArray(data) ? data : (data.results || []);
    renderApplications();
  } finally {
    $("#applications-loading").classList.add("hidden");
  }
}

function renderApplications() {
  const list = $("#applications-list");
  if (!state.applications.length) {
    list.innerHTML = `<div class="item"><p class="muted">No applications match this filter.</p></div>`;
    return;
  }
  list.innerHTML = state.applications.map(a => `
    <article class="item">
      <div class="item-head">
        <div>
          <h3 class="item-title">${escapeHtml(a.candidate_name)}</h3>
          <p class="muted">${escapeHtml(a.candidate_email)} · ${escapeHtml(a.opportunity_title)}</p>
        </div>
        <span class="badge">${escapeHtml(a.status)}</span>
      </div>
      <p>${escapeHtml(a.cover_letter || "No cover letter provided.")}</p>
      <div class="meta">
        ${a.resume_name ? `<span class="badge">Resume: ${escapeHtml(a.resume_name)}</span>` : `<span class="badge">No resume reference</span>`}
        <span class="badge">Applied: ${new Date(a.applied_at).toLocaleString()}</span>
      </div>
      <div class="actions">
        <button class="btn btn-ghost" data-review-application="${a.id}">Review</button>
        ${!["selected","rejected","withdrawn"].includes(a.status) ? `<button class="btn btn-primary" data-status-application="${a.id}">Update status</button>` : ""}
        ${!["rejected","withdrawn"].includes(a.status) ? `<button class="btn btn-ghost" data-schedule-interview="${a.id}">Schedule interview</button>` : ""}
      </div>
    </article>
  `).join("");
}

async function openApplicationReview(id) {
  const a = await api(`/applications/${id}/`);
  const history = (a.status_history || []).map(h => `${h.old_status || "—"} → ${h.new_status}: ${h.note || ""}`).join("\n");
  alert(
    `Candidate: ${a.candidate_name}\nEmail: ${a.candidate_email}\nOpportunity: ${a.opportunity_title}\nStatus: ${a.status}\n\nCover letter:\n${a.cover_letter || "None"}\n\nStatus history:\n${history || "No history"}`
  );
}

function openStatusModal(id) {
  $("#status-form").reset();
  $("#status-form").elements.id.value = id;
  $("#status-modal").classList.remove("hidden");
}

async function saveStatus(event) {
  event.preventDefault();
  const payload = formObject(event.currentTarget);
  await api(`/applications/${payload.id}/status/`, {
    method: "POST",
    body: { status: payload.status, note: payload.note }
  });
  closeModals();
  await loadApplications();
  showMessage("success", "Application status updated.");
}

function openInterviewModal(applicationId) {
  const form = $("#interview-form");
  form.reset();
  form.elements.application.value = applicationId;
  $("#interview-modal").classList.remove("hidden");
}

async function saveInterview(event) {
  event.preventDefault();
  const payload = formObject(event.currentTarget);
  payload.scheduled_at = toApiDate(payload.scheduled_at);
  await api("/interviews/", { method: "POST", body: payload });
  closeModals();
  await Promise.all([loadApplications(), loadInterviews()]);
  showMessage("success", "Interview scheduled.");
}

async function loadInterviews() {
  $("#interviews-loading").classList.remove("hidden");
  try {
    const data = await api("/interviews/");
    state.interviews = Array.isArray(data) ? data : (data.results || []);
    renderInterviews();
  } finally {
    $("#interviews-loading").classList.add("hidden");
  }
}

function renderInterviews() {
  const list = $("#interviews-list");
  if (!state.interviews.length) {
    list.innerHTML = `<div class="item"><p class="muted">No interviews scheduled.</p></div>`;
    return;
  }
  list.innerHTML = state.interviews.map(i => `
    <article class="item">
      <div class="item-head">
        <div>
          <h3 class="item-title">${escapeHtml(i.mode || "Interview")}</h3>
          <p class="muted">${new Date(i.scheduled_at).toLocaleString()}</p>
        </div>
        <span class="badge">${escapeHtml(i.status)}</span>
      </div>
      <p>${escapeHtml(i.instructions || "No instructions.")}</p>
      ${i.location_or_link ? `<p><a href="${escapeAttribute(i.location_or_link)}" target="_blank" rel="noopener noreferrer">Open meeting/location</a></p>` : ""}
    </article>
  `).join("");
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;" }[ch]));
}
function escapeAttribute(value) { return escapeHtml(value); }

function activateSection(name) {
  $$(".tab").forEach(tab => tab.classList.toggle("active", tab.dataset.section === name));
  $$(".section").forEach(section => section.classList.add("hidden"));
  $(`#${name}-section`).classList.remove("hidden");

  if (name === "opportunities") loadOpportunities().catch(e => showMessage("error", e.message));
  if (name === "applications") loadApplications().catch(e => showMessage("error", e.message));
  if (name === "interviews") loadInterviews().catch(e => showMessage("error", e.message));
}

async function logout() {
  await api("/auth/logout/", { method: "POST" });
  window.location.href = "../../index.html";
}

async function init() {
  try {
    await api("/auth/me/"); // also creates the CSRF cookie through Django's session flow
    await loadMe();
    await Promise.all([loadProfile(), loadCompanies()]);
  } catch (error) {
    if (error.status === 401) {
      window.location.href = "../../index.html";
      return;
    }
    showMessage("error", error.message);
  }
}

document.addEventListener("click", async event => {
  const edit = event.target.closest("[data-edit-opportunity]");
  const status = event.target.closest("[data-opportunity-status]");
  const review = event.target.closest("[data-review-application]");
  const update = event.target.closest("[data-status-application]");
  const schedule = event.target.closest("[data-schedule-interview]");

  try {
    if (edit) openOpportunityModal(state.opportunities.find(o => o.id === edit.dataset.editOpportunity));
    if (status) await updateOpportunityStatus(status.dataset.opportunityStatus, status.dataset.status);
    if (review) await openApplicationReview(review.dataset.reviewApplication);
    if (update) openStatusModal(update.dataset.statusApplication);
    if (schedule) openInterviewModal(schedule.dataset.scheduleInterview);
  } catch (error) {
    showMessage("error", error.message);
  }
});

$$(".tab").forEach(tab => tab.addEventListener("click", () => activateSection(tab.dataset.section)));
$("#profile-form").addEventListener("submit", e => saveProfile(e).catch(err => showMessage("error", err.message)));
$("#company-form").addEventListener("submit", e => saveCompany(e).catch(err => showMessage("error", err.message)));
$("#opportunity-form").addEventListener("submit", e => saveOpportunity(e).catch(err => showMessage("error", err.message)));
$("#status-form").addEventListener("submit", e => saveStatus(e).catch(err => showMessage("error", err.message)));
$("#interview-form").addEventListener("submit", e => saveInterview(e).catch(err => showMessage("error", err.message)));
$("#new-opportunity-btn").addEventListener("click", () => openOpportunityModal());
$("#application-status-filter").addEventListener("change", () => loadApplications().catch(err => showMessage("error", err.message)));
$("#application-mode").addEventListener("change", toggleExternalUrl);
$("#logout-btn").addEventListener("click", () => logout().catch(err => showMessage("error", err.message)));
$$("[data-close-modal]").forEach(btn => btn.addEventListener("click", closeModals));

init();
