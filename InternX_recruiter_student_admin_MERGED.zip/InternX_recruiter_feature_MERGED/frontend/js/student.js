async function studentLogin(e){
 e.preventDefault(); const button=e.target.querySelector("button"); button.disabled=true;
 try { await api("/api/auth/student/login/",{method:"POST",body:JSON.stringify({email:e.target.email.value,password:e.target.password.value})}); location.href="/pages/student/dashboard.html"; }
 catch(err){showError("auth-error",err)} finally{button.disabled=false}
}
async function studentRegister(e){
 e.preventDefault(); const button=e.target.querySelector("button"); button.disabled=true;
 try { await api("/api/auth/student/register/",{method:"POST",body:JSON.stringify({email:e.target.email.value,password:e.target.password.value,first_name:e.target.first_name.value,last_name:e.target.last_name.value})}); location.href="/pages/student/dashboard.html"; }
 catch(err){showError("auth-error",err)} finally{button.disabled=false}
}
async function loadProfile(){
 const p=await api("/api/students/profile/"); for(const key of ["first_name","last_name","phone","date_of_birth","bio","location","graduation_year"]){const el=document.getElementById(key);if(el)el.value=p[key]??""}
}
async function saveProfile(e){
 e.preventDefault(); const button=e.target.querySelector("button");button.disabled=true;
 try{await api("/api/students/profile/",{method:"PATCH",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});document.getElementById("save-message").textContent="Profile saved."}
 catch(err){showError("profile-error",err)}finally{button.disabled=false}
}
async function loadOpportunities(){
 const list=document.getElementById("opportunities"); list.innerHTML="<p>Loading...</p>";
 const params=new URLSearchParams(new FormData(document.getElementById("filters")));
 try{
  const data=await api("/api/opportunities/student/?"+params.toString());
  list.innerHTML=(data.results||[]).map(o=>`<article><h3>${esc(o.title)}</h3><p>${esc(o.company_name)}</p><p>${esc(o.opportunity_type)} · ${esc(o.work_mode||"")}</p><p>${esc(o.location||"Location not specified")}</p><a href="/pages/opportunities/detail.html?id=${encodeURIComponent(o.id)}">Details</a></article>`).join("")||"<p>No opportunities found.</p>";
 }catch(err){list.innerHTML=`<p role="alert">${esc(err.message)}</p>`}
}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
async function loadApplications(){
 const list=document.getElementById("applications");list.innerHTML="<p>Loading...</p>";
 try{const d=await api("/api/applications/student/");list.innerHTML=(d.results||[]).map(a=>`<article><h3>${esc(a.opportunity_title)}</h3><p>${esc(a.company_name)} · ${esc(a.status)}</p><a href="/pages/student/application.html?id=${a.id}">View</a></article>`).join("")||"<p>No applications.</p>"}
 catch(err){list.innerHTML=`<p role="alert">${esc(err.message)}</p>`}
}
