async function getCsrfToken() {
  const response = await fetch("/api/auth/csrf/", {credentials:"include"});
  if (!response.ok) throw new Error("Unable to initialize secure session.");
  const data = await response.json();
  return data.csrfToken || getCookie("csrftoken");
}
function getCookie(name) {
  return document.cookie.split("; ").find(x=>x.startsWith(name+"="))?.split("=")[1] || "";
}
async function api(path, options={}) {
  const method=(options.method||"GET").toUpperCase();
  const headers={Accept:"application/json",...(options.headers||{})};
  if (!(options.body instanceof FormData) && options.body !== undefined) headers["Content-Type"]="application/json";
  if (!["GET","HEAD","OPTIONS"].includes(method)) {
    const token=await getCsrfToken();
    headers["X-CSRFToken"]=token;
  }
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),15000);
  try {
    const response=await fetch(path,{...options,method,headers,credentials:"include",signal:controller.signal});
    const type=response.headers.get("content-type")||"";
    const data=type.includes("application/json")?await response.json():null;
    if(!response.ok) {
      const msg=data?.detail || Object.values(data||{}).flat().join(" ") || `Request failed (${response.status})`;
      throw new Error(msg);
    }
    return data;
  } catch(e) {
    if(e.name==="AbortError") throw new Error("Request timed out. Please try again.");
    throw e;
  } finally { clearTimeout(timeout); }
}
function showError(id,error){const el=document.getElementById(id);if(el)el.textContent=error.message||String(error);}
