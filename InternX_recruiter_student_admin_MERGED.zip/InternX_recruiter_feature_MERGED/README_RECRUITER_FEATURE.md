# InternX Recruiter Feature

This implementation follows the supplied InternX architecture:
HTML/CSS/JavaScript → Django REST Framework → Supabase PostgreSQL.

Implemented recruiter scope:
- Recruiter registration and login
- Recruiter profile
- Company profile
- Create/edit opportunity
- Publish/close opportunity
- View applications
- Candidate review
- Application status updates
- Interview scheduling and updates

## Important existing-code note

The supplied landing page currently performs authentication directly with Supabase from `script.js`.
The project architecture documents Django Authentication as the primary authentication layer.
For this feature, recruiter authentication is therefore implemented through Django sessions and DRF.

Do not put the Supabase service-role key in browser code. Only the public/anon key may ever be exposed to a browser, and the recommended architecture keeps database access behind Django.

## Setup

1. Create a Python virtual environment.
2. Install `backend/requirements.txt`.
3. Copy `backend/.env.example` to `backend/.env` and set your Supabase PostgreSQL connection values.
4. Run:
   `python manage.py makemigrations`
   `python manage.py migrate`
   `python manage.py runserver`
5. Serve the frontend with a local HTTP server, or configure Django to serve it.
   Example:
   `python -m http.server 5500 --directory frontend`
6. Open:
   `http://127.0.0.1:5500/pages/recruiter/recruiter-dashboard.html`

## API endpoints

POST `/api/auth/recruiter/register/`
POST `/api/auth/recruiter/login/`
POST `/api/auth/logout/`
GET  `/api/auth/me/`

GET/PUT `/api/recruiters/profile/`

GET/POST `/api/companies/`
GET/PUT `/api/companies/<uuid>/`

GET/POST `/api/opportunities/mine/`
GET/PUT/PATCH `/api/opportunities/<uuid>/`
POST `/api/opportunities/<uuid>/status/`

GET `/api/applications/mine/`
GET `/api/applications/<uuid>/`
POST `/api/applications/<uuid>/status/`

GET/POST `/api/interviews/`
PUT/PATCH `/api/interviews/<uuid>/`

## Validation and security

Server-side validation is authoritative. The backend:
- restricts recruiter endpoints to active recruiter accounts;
- prevents recruiters from accessing another recruiter's opportunities/applications;
- validates salary ranges;
- requires an external URL for external application mode;
- prevents publishing without a future deadline;
- prevents reopening a closed opportunity;
- prevents recruiter status changes to withdrawn applications;
- records application status history;
- prevents interviews for rejected/withdrawn applications;
- creates a student notification when an interview is scheduled.

The exact company verification workflow remains intentionally unimplemented because the supplied PRD marks it as an open product decision.

## Security and maintenance fixes included

- Added app migrations for all recruiter feature models.
- Enforced recruiter ownership when changing an opportunity's company.
- Made interview application immutable after creation to prevent cross-recruiter reassignment.
- Added Django password validation during recruiter registration.
- Added login and registration throttling.
- Added application/interview status transition validation.
- Added a database constraint allowing only one primary company per recruiter.
- Converted notification references to real foreign keys.
- Added pagination to recruiter opportunity, application, and interview list APIs.
- Hardened production secret/debug configuration.
- Added regression tests for the critical authorization/password cases.

### Local setup

1. Copy `backend/.env.example` to `backend/.env`.
2. Set a strong `DJANGO_SECRET_KEY`.
3. For local development, set `DJANGO_DEBUG=True`.
4. Configure PostgreSQL values in `.env`.
5. From `backend/`, run `python manage.py migrate`.
6. Run the test suite with `pytest`.

The frontend accepts `window.INTERNX_API_BASE` when a deployment needs a different API base URL; otherwise it keeps the local development API default.
